package tokigames;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import tokigames.constants.TokiConstant;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class TokiUnitTest {

	@Autowired
	private MockMvc mockMvc;
	
	@Test
	public void testWithNoDepStationArrStation() throws Exception {
		String json = "{ \"departureStation\": \"\",\r\n" + 
				"  \"arrivalStation\": \"\",\r\n" + 
				"  \"departureDate\": \"2019-12-01 12:00:00\",\r\n" +
				"  \"arrivalDate\": \"2019-12-01 12:00:00\"\r\n" + 
				"}";
		this.mockMvc.perform(
				post(TokiConstant.FLIGHT_SEARCH_MAPPING)
				.contentType(MediaType.APPLICATION_JSON)
				.content(json))
				.andExpect(status().isOk())
				.andReturn();
	}
	
	@Test
	public void testWithNoDepStation() throws Exception {
		String json = "{ \"departureStation\": \"\",\r\n" + 
				"  \"arrivalStation\": \"Antalya\",\r\n" + 
				"  \"departureDate\": \"2019-12-01 12:00:00\",\r\n" +
				"  \"arrivalDate\": \"2019-12-01 12:00:00\"\r\n" + 
				"}";
		this.mockMvc.perform(
				post(TokiConstant.FLIGHT_SEARCH_MAPPING)
				.contentType(MediaType.APPLICATION_JSON)
				.content(json))
				.andExpect(status().isOk())
				.andReturn();
	}
	
	@Test
	public void testWithNoArrStation() throws Exception {
		String json = "{ \"departureStation\": \"Ankara\",\r\n" + 
				"  \"arrivalStation\": \"\",\r\n" + 
				"  \"departureDate\": \"2019-12-01 12:00:00\",\r\n" +
				"  \"arrivalDate\": \"2019-12-01 12:00:00\"\r\n" + 
				"}";
		this.mockMvc.perform(
				post(TokiConstant.FLIGHT_SEARCH_MAPPING)
				.contentType(MediaType.APPLICATION_JSON)
				.content(json))
				.andExpect(status().isOk())
				.andReturn();
	}
	
	@Test
	public void testWithNoDepStationArrStationFlux() throws Exception {
		String json = "{ \"departureStation\": \"\",\r\n" + 
				"  \"arrivalStation\": \"\",\r\n" + 
				"  \"departureDate\": \"2019-12-01 12:00:00\",\r\n" +
				"  \"arrivalDate\": \"2019-12-01 12:00:00\"\r\n" + 
				"}";
		this.mockMvc.perform(
				post(TokiConstant.FLIGHT_SEARCH_MAPPING_FLUX)
				.contentType(MediaType.APPLICATION_JSON)
				.content(json))
				.andExpect(status().isOk())
				.andReturn();
	}
	
	@Test
	public void testWithNoDepStationFlux() throws Exception {
		String json = "{ \"departureStation\": \"\",\r\n" + 
				"  \"arrivalStation\": \"Antalya\",\r\n" + 
				"  \"departureDate\": \"2019-12-01 12:00:00\",\r\n" +
				"  \"arrivalDate\": \"2019-12-01 12:00:00\"\r\n" + 
				"}";
		this.mockMvc.perform(
				post(TokiConstant.FLIGHT_SEARCH_MAPPING_FLUX)
				.contentType(MediaType.APPLICATION_JSON)
				.content(json))
				.andExpect(status().isOk())
				.andReturn();
	}
	
	@Test
	public void testWithNoArrStationFlux() throws Exception {
		String json = "{ \"departureStation\": \"Ankara\",\r\n" + 
				"  \"arrivalStation\": \"\",\r\n" + 
				"  \"departureDate\": \"2019-12-01 12:00:00\",\r\n" +
				"  \"arrivalDate\": \"2019-12-01 12:00:00\"\r\n" + 
				"}";
		this.mockMvc.perform(
				post(TokiConstant.FLIGHT_SEARCH_MAPPING_FLUX)
				.contentType(MediaType.APPLICATION_JSON)
				.content(json))
				.andExpect(status().isOk())
				.andReturn();
	}
}

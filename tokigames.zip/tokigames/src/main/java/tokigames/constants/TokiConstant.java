package tokigames.constants;

public class TokiConstant {
	
	public TokiConstant() {
		
	}
	public static final String FLIGHT_SEARCH_MAPPING="/app/flightMapping";
	public static final String FLIGHT_SEARCH_MAPPING_FLUX="/app/flightMappingFlux";
	public static final String CHEAP_FLIGHT_URL="https://tokigames-challenge.herokuapp.com/api/flights/cheap";
	public static final String BUSSINES_FLIGHT_URL="https://tokigames-challenge.herokuapp.com/api/flights/business";
	public static final String CHEAP_FLIGHT="CHEAP";
	public static final String BUSINESS_FLIGHT="BUSINESS";
}

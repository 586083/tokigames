package tokigames.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import reactor.core.publisher.Flux;
import tokigames.constants.TokiConstant;
import tokigames.dto.Flights;
import tokigames.service.FlightService;

@RestController
public class FlightSearchController {
	
	@Autowired
	private FlightService flightServiceImpl;
	
	@PostMapping(value = TokiConstant.FLIGHT_SEARCH_MAPPING)
	public List<Flights> getFlight(@RequestBody Flights flight){
		return flightServiceImpl.getFlight(flight);
	}
	
	@PostMapping(value = TokiConstant.FLIGHT_SEARCH_MAPPING_FLUX)
	public Flux<Flights> getFlightFlux(@RequestBody Flights flight){
		return flightServiceImpl.getFlightFlux(flight);
	}
	
}

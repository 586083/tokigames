package tokigames.util;

import java.util.List;

public class DataUtils {

	public static String[] splitSector(String sector) {
		if(sector == null) {
			return new String[1];
		}
		return sector.split("-");
	}
	
	public static boolean isEmpty(String s) {
		return s == null || s.trim().length() == 0;
	}
}

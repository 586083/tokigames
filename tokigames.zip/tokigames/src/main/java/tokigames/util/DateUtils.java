package tokigames.util;

import java.util.Date;

public class DateUtils {
	
	public static Date convertMilliSecondToDate(double milliSec) {
		return new Date((int) milliSec);
	}
}

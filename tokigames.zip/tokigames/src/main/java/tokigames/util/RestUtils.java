package tokigames.util;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import tokigames.dto.BusinessFlightData;
import tokigames.dto.CheapFlightData;

@Component
public class RestUtils {
	
	private static RestTemplate restTemplate = new RestTemplate();
	
	@SuppressWarnings("unchecked")
	public static <T> T fetchMultiple(String url,int type)  {
		try {
			switch (type) {
			case 1:
				CheapFlightData obj=restTemplate.getForObject(url, CheapFlightData.class);
				return (T) obj;
			case 2:
				BusinessFlightData obj1=restTemplate.getForObject(url, BusinessFlightData.class);
				return (T) obj1;
			default:
				break;
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}

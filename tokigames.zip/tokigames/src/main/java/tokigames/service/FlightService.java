package tokigames.service;

import java.util.List;

import reactor.core.publisher.Flux;
import tokigames.dto.Flights;

public interface FlightService {
	public List<Flights> getFlight(Flights flight);
	public Flux<Flights> getFlightFlux(Flights flight);
}

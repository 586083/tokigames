package tokigames.service.Impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import reactor.core.publisher.Flux;
import tokigames.constants.TokiConstant;
import tokigames.dto.BusinessFlightData;
import tokigames.dto.CheapFlightData;
import tokigames.dto.Flights;
import tokigames.service.FlightService;
import tokigames.util.DataUtils;
import tokigames.util.DateUtils;
import tokigames.util.RestUtils;

@Service
public class FlightServiceImpl implements FlightService{

	/**
	 *Main method to fetch list of flight
	 */
	public List<Flights> getFlight(Flights flight) {
		CheapFlightData cheapFlightData=RestUtils.fetchMultiple(TokiConstant.CHEAP_FLIGHT_URL, 1);
		BusinessFlightData bussinessFlightData=RestUtils.fetchMultiple(TokiConstant.BUSSINES_FLIGHT_URL,2);
		List<Flights> finalList=aggregateFlights(cheapFlightData,bussinessFlightData);
		List<Flights> filterdFlight=filterFlight(finalList,flight);
		return filterdFlight;
	}
	
	/**
	 *Main method to fetch list of flight using Flux
	 */
	public Flux<Flights> getFlightFlux(Flights flight) {
		CheapFlightData cheapFlightData=RestUtils.fetchMultiple(TokiConstant.CHEAP_FLIGHT_URL, 1);
		BusinessFlightData bussinessFlightData=RestUtils.fetchMultiple(TokiConstant.BUSSINES_FLIGHT_URL,2);
		List<Flights> finalList=aggregateFlights(cheapFlightData,bussinessFlightData);
		List<Flights> filterdFlight=filterFlight(finalList,flight);
		return Flux.fromIterable(filterdFlight);
	}
	
	/**
	 * To Filter flight based on Dep station and Arr station
	 * To sort flight based on Dep station
	 * @param finalList
	 * @param flight
	 * @return
	 */
	private List<Flights> filterFlight(List<Flights> finalList,Flights flight) {
		return finalList.stream().sorted(Comparator.comparing(Flights::getDepartureStation)).filter(predicateFlightFilter(flight)).collect(Collectors.toList());
	}
	
	
	/**
	 * To Filter Flights based on Dep station and Arr station
	 * @param flight
	 * @return
	 */
	private Predicate<Flights> predicateFlightFilter(Flights flight) {
		return  p -> (
				//departure predicate
				((DataUtils.isEmpty(flight.getDepartureStation())) || (flight.getDepartureStation().equals(p.getDepartureStation())))
				&&
				//arrival predicate
				((DataUtils.isEmpty(flight.getArrivalStation())) || (flight.getArrivalStation().equals(p.getArrivalStation()))));
	}

	/**
	 * To combine flight from both services
	 * @param cheapFlight
	 * @param bussinesFlight
	 * @return
	 */
	private List<Flights> aggregateFlights(CheapFlightData cheapFlight, BusinessFlightData bussinesFlight) {
		List<Flights> finalList=new ArrayList<>();
		if(cheapFlight != null) {
		//convert cheap flight to common flight structure
		cheapFlight.getData().stream().forEach( obj -> {
			Flights temp=new Flights();
			//setting sector
			String[] sectorArray=DataUtils.splitSector(obj.getRoute());
			if(sectorArray.length > 1) {
				temp.setDepartureStation(sectorArray[0]);
				temp.setArrivalStation(sectorArray[1]);
			}
			//setting other details
			temp.setDepartureDate(DateUtils.convertMilliSecondToDate(obj.getDeparture()));
			temp.setArrivalDate(DateUtils.convertMilliSecondToDate(obj.getArrival()));
			temp.setCategory(TokiConstant.CHEAP_FLIGHT);
			finalList.add(temp);
		});
		}
		if(bussinesFlight != null) {
		//convert bussines flight to common flight structure
		bussinesFlight.getData().stream().forEach( obj -> {
			Flights temp=new Flights();
			//setting sector
			temp.setDepartureStation(obj.getDeparture());
			temp.setArrivalStation(obj.getArrival());
			temp.setDepartureDate(DateUtils.convertMilliSecondToDate(obj.getDepartureTime()));
			temp.setArrivalDate(DateUtils.convertMilliSecondToDate(obj.getArrivalTime()));
			temp.setCategory(TokiConstant.BUSINESS_FLIGHT);
			finalList.add(temp);
		});
		}
		return finalList;
	}
	
}

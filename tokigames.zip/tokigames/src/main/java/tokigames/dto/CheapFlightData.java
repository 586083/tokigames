package tokigames.dto;

import java.util.List;

	
public class CheapFlightData {
	private List<CheapFlights> data;

	public List<CheapFlights> getData() {
		return data;
	}

	public void setData(List<CheapFlights> data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "CheapFlightData [data=" + data + "]";
	}
	
	
}

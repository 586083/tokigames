package tokigames.dto;

public class CheapFlights {
	private String route;
	private double departure;
	private double arrival;
	public String getRoute() {
		return route;
	}
	public void setRoute(String route) {
		this.route = route;
	}
	public double getDeparture() {
		return departure;
	}
	public void setDeparture(double departure) {
		this.departure = departure;
	}
	public double getArrival() {
		return arrival;
	}
	public void setArrival(double arrival) {
		this.arrival = arrival;
	}
	@Override
	public String toString() {
		return "CheapFlights [route=" + route + ", departure=" + departure + ", arrival=" + arrival + "]";
	}
	
}

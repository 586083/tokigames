package tokigames.dto;

import java.util.List;

public class BusinessFlightData {
	private List<BusinessFlights> data;

	public List<BusinessFlights> getData() {
		return data;
	}

	public void setData(List<BusinessFlights> data) {
		this.data = data;
	}
	
}
